/*
 Name:		BlueToyLib.h
 Created:	04/06/2016 13:19:20
 Author:	andre
 Editor:	http://www.visualmicro.com
*/

#ifndef _BlueToyLib_h
#define _BlueToyLib_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
	#include <CurieBLE.h>
	
#else
	#include "WProgram.h"
#endif
class BlueToyClass
{


public:
	BlueToyClass();
	void init();
	void processMessage(BLECharacteristic data, int id);
	void processGestureElement(BLECharacteristic datax);
	void processGesture(BLECharacteristic datax);
	void processProfile(BLECharacteristic datax);
	void processLink(BLECharacteristic datax);
	byte typeValue(char type);
	byte idValue(char a);
	byte peripheralValue(char one);
	byte timesValue(char times);
	int eAddressGestureElement(int address);
	int eAddressGesture(int address);
	int eAddressProfile(int address);
	int eAddressLink(int address);
	void gestureElementModify(byte iden, byte peri, byte veces);
	void gestureElementEmpty(byte iden);
	void gestureModify(byte iden, byte idW0, byte idW1, byte idW2, byte idW3, byte idW4);
	void gestureEmpty(byte iden);
	void profileModify(byte iden, byte app, byte contact);
	void profileEmpty(byte iden);
	void linkModify(byte iden, byte idges, byte idprof);
	void linkEmpty(byte iden);

};

//extern BlueToyClass BlueToy;




#endif

