/*
 Name:		BlueToyLib.cpp
 Created:	04/06/2016 13:19:20
 Author:	andre
 Editor:	http://www.visualmicro.com
*/

#include "BlueToyLib.h"
#include <CurieBLE.h>
#include <Arduino.h>
#include <CurieEEPROM.h>
#include <WString.h>


BlueToyClass::BlueToyClass()
{

}

void BlueToyClass::init()
{

}
/*
Method to process the different kind of messages
*/
void BlueToyClass::processMessage(BLECharacteristic data, int id)
{

	digitalWrite(10, HIGH);
	delay(500);
	digitalWrite(10, LOW);
	delay(1000);
	/*switch (id)
	{
		//gestureElementCharacteristicWritten
		case 0:
		{
			
			// central wrote new value to characteristic, update gestureElements list
			//processGestureElement(data);
			Serial.print("\ngestureElementCharacteristic event, written: \n");
			Serial.print("\n type: " + (String)data[0]);
			Serial.print("\n Gesture Element Id: " + (String)data[1]);
			Serial.print("\n Peripheral Function: " + (String)data[2]);
			Serial.print("\n Times: " + (String)data[3]);
			digitalWrite(10, HIGH);
			delay(500);
			digitalWrite(10, LOW);
			delay(1000);
			
    
			break;
		}
		//gestureCharacteristicWritten
		case 1:
		{
			//processGesture(data);
			Serial.print("\ngestureCharacteristic event, written: \n");
			Serial.print("\ntype: " + (String)data[0]);
			Serial.print("\nGesture Id: " + (String)data[1]);
			Serial.print("\nGesture Element Id 1: " + (String)data[2]);
			Serial.print("\nGesture Element Id 2: " + (String)data[3]);
			Serial.print("\nGesture Element Id 3: " + (String)data[4]);
			Serial.print("\nGesture Element Id 4: " + (String)data[5]);
			Serial.print("\nGesture Element Id 5: " + (String)data[6]);
			digitalWrite(11, HIGH);
			delay(500);
			digitalWrite(11, LOW);
			break;
		}
		//profileCharacteristicWritten
		case 2:
		{
			//processProfile(data);
			Serial.print("\nprofileCharacteristic event, written: ");
			Serial.print("\ntype: " + (String)data[0]);
			Serial.print("\nProfile Id: " + (String)data[1]);
			Serial.print("\nApp Id: " + (String)data[2]);
			Serial.print("\nContact Id: " + (String)data[3]);
			digitalWrite(12, HIGH);
			delay(500);
			digitalWrite(12, LOW);
			break;
		}
		//linkCharacteristicWritten
		case 3:
		{
			//processLink(data);

			Serial.print("\nlinkCharacteristic event, written: \n");
			Serial.print("\ntype: " + (String)data[0]);
			Serial.print("\nLink Id: " + (String)data[1]);
			Serial.print("\nGesture Id: " + (String)data[2]);
			Serial.print("\nProfile Id: " + (String)data[3]);
			digitalWrite(13, HIGH);
			delay(500);
			digitalWrite(13, LOW);
			break;
		}

		default:
		{
			//error en la lectura
			break;
		}
	}*/

	

}
void BlueToyClass::processGestureElement(BLECharacteristic datax)
{
	//Serial.print((char)toAscii(data[0]) + (char)toAscii(data[1]) + (char)toAscii(data[2]) + "Valio\n\n"); 
	//eg (msgtype,ID,peripheral,function,times)--->>(1charto int,2chars to int, 3char to string, 1 char to int)
		
	byte type=typeValue(datax[0]);
	byte iden=idValue(datax[1]);
	byte peri=peripheralValue(datax[2]);
	byte veces=timesValue(datax[3]);

           

	switch (type)
	{
	case 0:
	{
		//modify
		gestureElementModify(iden, peri, veces);
		break;
			
	}
	case 1:
	{
		//empty
		gestureElementEmpty(iden);
		break;
	}
	case 2:
	{
		//query
		int dir = eAddressGestureElement(iden);
		EEPROM.get(dir, iden);
		EEPROM.get(dir + 1, peri);
		EEPROM.get(dir + 2, veces);
		break;
	}
	default:
	{
		//mensaje invalido
		break;
	}
	}

}

void BlueToyClass::processGesture(BLECharacteristic datax)
{
	byte type = typeValue(datax[0]);
	byte iden = idValue(datax[1]);
	byte idW0 = idValue(datax[2]);
	byte idW1 = idValue(datax[3]);
	byte idW2 = idValue(datax[4]);
	byte idW3 = idValue(datax[5]);
	byte idW4 = idValue(datax[6]);

	
	switch (type)
	{
	case 0:
	{
		//modify

		gestureModify(iden, idW0,idW1,idW2,idW3,idW4);
		
		break;
	}
	case 1:
	{
		//empty
		gestureEmpty(iden);
		break;
		
	}
	case 2:
	{
		//query
		int dir = eAddressGesture(iden);
		EEPROM.get(dir, iden);
		EEPROM.get(dir + 1, idW0);
		EEPROM.get(dir + 2, idW1);
		EEPROM.get(dir + 3, idW2);
		EEPROM.get(dir + 4, idW3);
		EEPROM.get(dir + 5, idW4);
		break;
	}
	default:
	{
		//mensaje invalido
		break;
	}
	}
}
void BlueToyClass::processProfile(BLECharacteristic datax)
{
	byte type = typeValue(datax[0]);
	byte iden = idValue(datax[1]);
	byte app = idValue(datax[2]);
	byte contact = idValue(datax[3]);
	
	
	switch (type)
	{
	case 0:
	{
		//modify
		profileModify(iden, app,contact);
		break;
		
	}
	case 1:
	{
		//empty
		profileEmpty(iden);
		break;
		
	}
	case 2:
	{
		int dir = eAddressProfile(iden);
		//EEPROM.put(dir, iden);
		EEPROM.put(dir + 1, app);
		EEPROM.put(dir + 2, contact);
		break;

	}
	default:
	{
		//mensaje invalido
		break;
	}
	}
}
void BlueToyClass::processLink(BLECharacteristic datax)
{
	byte type = typeValue(datax[0]);
	byte iden = idValue(datax[1]);
	byte idges = idValue(datax[2]);
	byte idprof = idValue(datax[3]);


	
	switch (type)
	{
	case 0:
	{
		//modify
		linkModify(iden, idges, idprof);
		break;
		
	}
	case 1:
	{
		//empty
		linkEmpty(iden);
		break;

		
	}
	case 2:
	{
		int dir = eAddressLink(iden);
		EEPROM.get(dir, iden);
		EEPROM.get(dir + 1, idges);
		EEPROM.get(dir + 2, idprof);
		break;
	}
	default:
	{
		//mensaje invalido
		break;
	}

	}
}




byte BlueToyClass::typeValue(char type)
{
	byte tipe = type;
	return tipe;

}
byte BlueToyClass::idValue(char a)
{
	byte id = a;

	return id;
}

byte BlueToyClass::peripheralValue(char one)
{
	byte per = one;
	return per;
}

byte BlueToyClass::timesValue(char times)
{
	byte tim = times;
	return tim;

}

int BlueToyClass::eAddressGestureElement(int address)
{
	int dir = address * 3;
	return dir;
}
int BlueToyClass::eAddressGesture(int address)
{
	int dir = 200+address * 3 ;
	return dir;
}
int BlueToyClass::eAddressProfile(int address)
{
	int dir = 500 + address * 3;
	return dir;
}
int BlueToyClass::eAddressLink(int address)
{
	int dir = 1000 + address * 3;
	return dir;
}

void BlueToyClass::gestureElementModify(byte iden, byte peri, byte veces)
{
	int dir = eAddressGestureElement(iden);
	//EEPROM.put(dire, iden);
	EEPROM.put(dir + 1, peri);
	EEPROM.put(dir + 2, veces);
}

void BlueToyClass::gestureElementEmpty(byte iden)
{
	int dir = eAddressGestureElement(iden);
	//EEPROM.put(dire, iden);
	EEPROM.put(dir + 1, 0B11111111);
	EEPROM.put(dir + 2, 0B11111111);
}
void BlueToyClass::gestureModify(byte iden, byte idW0, byte idW1, byte idW2, byte idW3, byte idW4)
{
	int dir = eAddressGesture(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, idW0);
	EEPROM.put(dir + 2, idW1);
	EEPROM.put(dir + 3, idW2);
	EEPROM.put(dir + 4, idW3);
	EEPROM.put(dir + 5, idW4);
}
void BlueToyClass::gestureEmpty(byte iden)
{
	int dir = eAddressGesture(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, 0B11111111);
	EEPROM.put(dir + 2, 0B11111111);
	EEPROM.put(dir + 3, 0B11111111);
	EEPROM.put(dir + 4, 0B11111111);
	EEPROM.put(dir + 5, 0B11111111);
}
void BlueToyClass::profileModify(byte iden, byte app, byte contact)
{
	int dir = eAddressProfile(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, app);
	EEPROM.put(dir + 2, contact);
}
void BlueToyClass::profileEmpty(byte iden)
{
	int dir = eAddressProfile(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, 0B11111111);
	EEPROM.put(dir + 2, 0B11111111);
}
void BlueToyClass::linkModify(byte iden, byte idges, byte idprof)
{
	int dir = eAddressLink(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, idges);
	EEPROM.put(dir + 2, idprof);
}
void BlueToyClass::linkEmpty(byte iden)
{
	int dir = eAddressLink(iden);
	//EEPROM.put(dir, iden);
	EEPROM.put(dir + 1, 0B11111111);
	EEPROM.put(dir + 2, 0B11111111);
}
	//BlueToyClass BlueToy;





